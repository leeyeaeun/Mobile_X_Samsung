from . import (  # noqa: F401
    course_recommend,
    acrostic_generator,
    anime_characterize,
    interview_simulator,
    kospi_analyzer,
)
